# 1.0.0
- Only listen to powered-on walkies
- Limit distance at which users can hear walkied to 15

# 0.1.0
- Force all users able to hear walkies at all times