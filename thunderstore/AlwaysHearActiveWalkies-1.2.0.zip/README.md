# AlwaysHearActiveWalkies

AlwaysHearActiveWalkies improves the realism of the game a bit by allowing users to hear active walkies as long as they are close enough to one.

Now when you are exploring with someone who has a walkie you should be able to hear both sides of the conversation.

It also allows you to head active walkies on the floor which should give you a bit of an edge if the walkie-holder has just been face hugged.


## NOTE: This mod is under active development
